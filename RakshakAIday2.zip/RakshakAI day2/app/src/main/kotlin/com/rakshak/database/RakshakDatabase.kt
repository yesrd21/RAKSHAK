package com.rakshak.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.rakshak.database.dao.CallLogDao
import com.rakshak.database.dao.FraudReportDao
import com.rakshak.database.dao.ScanStatsDao
import com.rakshak.database.entities.CallLogEntry
import com.rakshak.database.entities.FraudReport
import com.rakshak.database.entities.ScanStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Rakshak Room Database
 * All data stored locally on device — no external servers.
 *
 * v1 → v2: Added call_log table for call shield feature.
 */
@Database(
    entities = [FraudReport::class, ScanStats::class, CallLogEntry::class],
    version = 2,
    exportSchema = false
)
abstract class RakshakDatabase : RoomDatabase() {

    abstract fun fraudReportDao(): FraudReportDao
    abstract fun scanStatsDao(): ScanStatsDao
    abstract fun callLogDao(): CallLogDao

    companion object {
        @Volatile
        private var INSTANCE: RakshakDatabase? = null

        /** Migration: v1 → v2 adds the call_log table. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS call_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        callerNumber TEXT NOT NULL,
                        riskScore INTEGER NOT NULL,
                        riskLevel TEXT NOT NULL,
                        signals TEXT NOT NULL,
                        isCorrelated INTEGER NOT NULL,
                        correlatedSmsScore INTEGER NOT NULL,
                        timestamp INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): RakshakDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RakshakDatabase::class.java,
                    "rakshak_database"
                )
                .addMigrations(MIGRATION_1_2)
                .addCallback(DatabaseCallback())
                .build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * Seed the initial ScanStats row on first creation.
         */
        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        database.scanStatsDao().insertStats(ScanStats(id = 1))
                    }
                }
            }
        }
    }
}

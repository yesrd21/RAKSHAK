package com.rakshak.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.util.Log
import com.rakshak.analyzer.CallRiskAnalyzer
import com.rakshak.calls.AutoCallTerminator
import com.rakshak.analyzer.RiskLevel
import com.rakshak.database.RakshakDatabase
import com.rakshak.database.entities.CallLogEntry
import com.rakshak.notifications.CallAlertManager
import com.rakshak.repository.FirestoreRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "CallReceiver"
    }

    private val firestoreRepo = FirestoreRepository()

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        @Suppress("DEPRECATION")
        val rawNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        Log.d(TAG, "Raw incoming number from intent: '$rawNumber'")

        CoroutineScope(Dispatchers.IO).launch {
            val incomingNumber = resolveNumber(context, rawNumber)
            Log.d(TAG, "Final resolved number: '$incomingNumber'")
            processCall(context, incomingNumber)
        }
    }
    /**
     * Tries every possible way to get the real number.
     * Polls for up to 5 seconds — MIUI delays number availability.
     */
    private suspend fun resolveNumber(context: Context, rawNumber: String?): String {

        // Step 1: intent already has a real number — use it immediately
        if (!rawNumber.isNullOrBlank() &&
            rawNumber != "Unknown" &&
            rawNumber != "Private" &&
            rawNumber != "Withheld" &&
            rawNumber != "-1") {
            Log.d(TAG, "Using number from intent: $rawNumber")
            return rawNumber
        }

        // Step 2: poll call log up to 10 times, 500ms apart (5 seconds total)
        repeat(10) { attempt ->
            Thread.sleep(500)
            val logNumber = getNumberFromCallLog(context)
            if (logNumber != null) {
                Log.d(TAG, "Got number from call log on attempt ${attempt + 1}: $logNumber")
                return logNumber
            }
            Log.d(TAG, "Call log attempt ${attempt + 1}: still no number")
        }

        // Step 3: truly hidden number
        Log.d(TAG, "Could not resolve number after 5s — treating as hidden")
        return "Unknown"
    }
    private suspend fun processCall(context: Context, incomingNumber: String) {
        val isHidden = incomingNumber.isBlank() ||
                incomingNumber == "Unknown" ||
                incomingNumber == "Private" ||
                incomingNumber == "Withheld" ||
                incomingNumber == "-1"

        // ── CONTACT CHECK — skip fraud analysis for known contacts ──────
        if (!isHidden) {
            val contactName = getContactName(context, incomingNumber)
            if (contactName != null) {
                Log.d(TAG, "Known contact: $contactName — skipping fraud analysis")
                return
            }
        }

        FraudSequenceStore.recordCall(
            callerNumber = incomingNumber,
            isUnknown    = isHidden,
            isHidden     = isHidden
        )

        val communityCount = firestoreRepo.getReportCountForSender(incomingNumber)
        val result = CallRiskAnalyzer.analyze(incomingNumber, communityCount)

        Log.d(TAG, "Call risk: ${result.riskScore} → ${result.riskLevel.label}")

        val terminationResult = if (result.riskScore >= AutoCallTerminator.TERMINATION_THRESHOLD) {
            AutoCallTerminator.evaluate(context, result)
        } else null

        if (result.riskLevel != RiskLevel.SAFE) {
            CallAlertManager.showCallAlert(context, incomingNumber, result, terminationResult)

            val db = RakshakDatabase.getDatabase(context)
            db.callLogDao().insertCallLog(
                CallLogEntry(
                    callerNumber       = if (result.isHidden) "Hidden/Private Number" else incomingNumber,
                    riskScore          = result.riskScore,
                    riskLevel          = result.riskLevel.label,
                    signals            = result.detectedSignals.joinToString("|"),
                    isCorrelated       = result.correlatedSms != null || result.sequenceMatch != null,
                    correlatedSmsScore = result.correlatedSms?.riskScore
                        ?: result.sequenceMatch?.smsEvent?.riskScore ?: 0
                )
            )
        }
    }

    /**
     * Returns the contact display name if the number exists in the device
     * contact book, null otherwise.
     *
     * Normalises the number before lookup — handles +91, leading 0, spaces etc.
     */
    private fun getContactName(context: Context, number: String): String? {
        return try {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(number)
            )
            val cursor: Cursor? = context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    it.getString(it.getColumnIndexOrThrow(ContactsContract.PhoneLookup.DISPLAY_NAME))
                } else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Contact lookup failed: ${e.message}")
            null  // fail safe — if lookup fails, continue with fraud analysis
        }
    }/**
     * Fallback: reads the most recent RINGING entry from call log.
     * Used when EXTRA_INCOMING_NUMBER is empty (common on Xiaomi MIUI).
     */
    private fun getNumberFromCallLog(context: Context): String? {
        return try {
            val cursor = context.contentResolver.query(
                android.provider.CallLog.Calls.CONTENT_URI,
                arrayOf(
                    android.provider.CallLog.Calls.NUMBER,
                    android.provider.CallLog.Calls.TYPE,
                    android.provider.CallLog.Calls.DATE
                ),
                "${android.provider.CallLog.Calls.TYPE} = ?",
                arrayOf(android.provider.CallLog.Calls.INCOMING_TYPE.toString()),
                "${android.provider.CallLog.Calls.DATE} DESC"
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val number = it.getString(
                        it.getColumnIndexOrThrow(android.provider.CallLog.Calls.NUMBER)
                    )
                    val date = it.getLong(
                        it.getColumnIndexOrThrow(android.provider.CallLog.Calls.DATE)
                    )
                    // Only use if this log entry is from the last 10 seconds
                    val ageMs = System.currentTimeMillis() - date
                    if (ageMs < 10_000 && !number.isNullOrBlank() &&
                        number != "-1" && number != "Unknown") {
                        Log.d(TAG, "Got number from call log: $number (age=${ageMs}ms)")
                        number
                    } else null
                } else null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Call log fallback failed: ${e.message}")
            null
        }
    }
}